from utils import err, c, fetch_all_packages, load_installed, resolve_package


def cmd_info(args):
    if not args:
        err("Usage: trk info <package[@version]>")
        return

    name = args[0]
    _, _, want_ver = name.partition("@")
    name = name.split("@")[0]
    pkgs = fetch_all_packages()
    installed = load_installed()

    # Fallback: если не найдено в репозиториях — спрашиваем crates.io
    pkg, from_crates = resolve_package(name, pkgs, want_ver or None)
    if not pkg:
        err(f"Package '{name}' not found (repositories or crates.io).")
        return

    inst   = installed.get(name)
    status = c("green", "Installed") if inst else c("yellow", "Not installed")
    deps   = pkg.get("depends", [])
    deps_str = ", ".join(deps) if deps else "none"

    print(f"""
  {c('bold', 'Package:')}     {c('cyan', name)}
  {c('bold', 'Version:')}     {pkg.get('version', '?')}
  {c('bold', 'Status:')}      {status}
  {c('bold', 'Description:')} {pkg.get('description', 'N/A')}
  {c('bold', 'URL:')}         {pkg.get('url', 'N/A')}
  {c('bold', 'Size:')}        {pkg.get('size', 'unknown')}
  {c('bold', 'Depends:')}     {deps_str}
  {c('bold', 'License:')}     {pkg.get('license', 'unknown')}
  {c('bold', 'Source:')}      {'crates.io (fallback)' if from_crates else pkg.get('source', 'repository index')}
""")
