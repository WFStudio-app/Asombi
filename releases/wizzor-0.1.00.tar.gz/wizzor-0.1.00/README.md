# Wizzor v0.1.00

Standalone package manager from Asombi OS.
Can be used independently on any Python 3 + proot environment.

## Quick start
```bash
python3 wiz help
```

© WFWorld — MIT License
